<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="HAGGAI mortgage.">
    <meta name="keywords" content="mortgage bank, in Nigeria, Lagos">
    <title>HAGGAI MORTGAGE</title>
    <!-- Bootstrap -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/fontello.css" rel="stylesheet">
   
    <!-- Google Fonts -->
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700%7CMerriweather:300,300i,400,400i,700,700i" rel="stylesheet">
    <!-- owl Carousel Css -->
    <link href="css/owl.carousel.css" rel="stylesheet">
    <link href="css/owl.theme.css" rel="stylesheet">
    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>

<body>
<div class="top-bar">
<!-- top-bar -->
<div class="container">
    <div class="row">
        <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12 d-none d-xl-block d-lg-block d-md-block">
            <p class="mail-text">Welcome to our Borrow Loan Website Templates</p>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 d-none d-xl-block d-lg-block d-md-block">
            <p class="mail-text text-center">Call us at 1-800-123-4567</p>
        </div>
        <div class="col-xl-3 col-lg-3 col-md-3 col-sm-12 col-12 d-none d-xl-block d-lg-block d-md-block">
            <p class="mail-text text-center">Mon to fri 10:00am - 06:00pm</p>
        </div>
        <div class="col-xl-2 col-lg-2 col-md-2 col-sm-12 col-12 d-none d-xl-block d-lg-block d-md-block">
            <p class="mail-text text-center">Get started today</p>
        </div>
    </div>
</div>
</div>
<!-- /.top-bar -->
<div class="header-2">
<div class="container">
    <div class="row">
        <div class="col-xl-3 col-lg-3 col-md-12 col-sm-12 col-12">
            <!-- logo -->
            <div class="logo">
                <a href="index.html"><img src="images/logo2.png" alt="Borrow - Loan Company Website Template"></a>
            </div>
        </div>
        <!-- logo -->
        <div class="col-xl-9 col-lg-9 col-md-12 col-sm-12 col-12 text-right d-none d-xl-block d-lg-block ">
            <div class="header-action">
                <a href="#" class="btn btn-primary">Loan Calculator</a>
                <a href="#" class="btn btn-default ">Online Calculator</a></div>
        </div>
    </div>
</div>
<div class="navigation-2">
    <div class="container">
        <div class="row">
            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
                   <div id="navigation">
                <!-- navigation start-->
                <ul>
                            <li class="active"><a href="#" class="animsition-link">Home</a>
                               
                            </li>
                            <li><a href="#" class="animsition-link">Mortgage Product</a>
                                <ul>
                                    
                                    
                                   
                                    <li><a href="#" title="Loan Image Listing" class="animsition-link">HAGGAI PLOT ADVANCE (HAPA)</a></li>
                                    <li><a href="loan-listing-icon.html" title="Loan Icon Listing" class="animsition-link">HAGGAI COMPLETION MORTGAGE LOAN (HAHCOM)</a></li>
                                    <li><a href="#" title="Car Loan" class="animsition-link">HAGGAI RENOVATION LOAN (HAREL)</a></li>
                                    <li><a href="#" title="Personal Loan" class="animsition-link">HAGGAI HOUSE PURCHASE LOAN (HAHP)</a></li>
                                    <li><a href="#" title="Home Loan" class="animsition-link">HAGGAI RENT LOAN (HARENT)</a></li>
                                    <li><a href="#" title="Education Loan" class="animsition-link">HAGGAI CAMP HOME ACCOUNT</a></li>
                                    <li><a href="#" title="Education Loan" class="animsition-link">MY OWN HOME SCHEME</a></li>
                                </ul>
                            </li>
                            <li><a href="#" class="#">Careers</a></li>
                            <li><a href="#" class="#">Financed Project</a></li>
                            <li><a href="#" class="#">Resources</a></li>
                            <li><a href="#" class="#">Contact</a></li>
                            
    </ul>
            </div>
                <!-- /.navigation start-->
            </div>
        </div>
    </div>
</div>
</div>
    <div class="slider" id="slider">
        <!-- slider -->
        <div class="slider-img"><img src="./images/slider-1.jpg" alt="Borrow - Loan Company Website Template" class="">
            <div class="container">
                <div class="row">
                    <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                        <div class="slider-captions">
                            <!-- slider-captions -->
                            <h1 class="slider-title">Personal Loan to Suit Your Needs. </h1>
                            <p class="slider-text d-none d-xl-block d-lg-block d-sm-block">The low rate you need for the need you want! Call
                                <br>
                                <strong class="text-highlight">07045994840</strong></p>
                            <a href="team.html" class="btn btn-default">Loan Products</a> </div>
                        <!-- /.slider-captions -->
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="slider-img"><img src="./images/slider-2.jpg" alt="Borrow - Loan Company Website Template" class="">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="slider-captions">
                                <!-- slider-captions -->
                                <h1 class="slider-title"> MY OWN HOME SCHEME <strong class="text-highlight">9.60%</strong> </h1>
                                <p class="slider-text d-none d-xl-block d-lg-block d-sm-block"> scheme is a public-private partnership that seeks to increase access to housing finance in Nigeria through mortgages, mortgage guarantee/insurance and housing microfinance. .</p>
                                <a href="#" class="btn btn-default">Read More</a> </div>
                            <!-- /.slider-captions -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="slider-img"><img src="./images/slider-4.jpg" alt="Borrow - Loan Company Website Template" class="">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="slider-captions">
                                <!-- slider-captions -->
                                <h1 class="slider-title"> HAGGAI RENOVATION LOAN (HAREL) <strong class="text-highlight">9.60%</strong> </h1>
                                <p class="slider-text d-none d-xl-block d-lg-block d-sm-block">This product is designed to assist our customers in renovating their properties so as to add value to same as well as beautifying their places of habitation while they enjoy capital appreciation on the properties.</p>
                                <a href="#" class="btn btn-default">Read More</a> </div>
                            <!-- /.slider-captions -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div>
            <div class="slider-img"><img src="./images/slider-3.jpg" alt="Borrow - Loan Company Website Template" class="">
                <div class="container">
                    <div class="row">
                        <div class="col-xl-6 col-lg-6 col-md-12 col-sm-12 col-12">
                            <div class="slider-captions">
                                <!-- slider-captions -->
                                <h1 class="slider-title">HAGGAI PLOT ADVANCE (HAPA) <strong class="text-highlight">11.10%</strong></h1>
                                <p class="slider-text d-none d-xl-block d-lg-block d-sm-block">The product is designed with the objective of assisting our customers to be proud owners oflanded properties <br>in prime locations which a view of building such eventually. .</p>
                                <a href="#" class="btn btn-default ">View Products</a> </div>
                            <!-- /.slider-captions -->
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="rate-table">
        <div class="container">
            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/mortgage.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">3.74%</h1>
                            <small class="rate-title">Home Loans</small>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/loan.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">8.96%</h1>
                            <small class="rate-title">Personal Loans</small>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/car.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">6.70%</h1>
                            <small class="rate-title">Car Loans</small>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="rate-counter-block">
                        <div class="icon rate-icon  "> <img src="images/credit-card.svg" alt="Borrow - Loan Company Website Template" class="icon-svg-1x"></div>
                        <div class="rate-box">
                            <h1 class="loan-rate">9.00%</h1>
                            <small class="rate-title">Credit card</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="section-space80 bg-gradient call-to-action">
        <div class="container">
            <div class="row">
                <div class=" offset-xl-2 col-xl-8 offset-lg-2 col-lg-8 col-md-12 col-sm-12 col-12">
                    <div class="text-center">
                        <!-- section title start-->
                        <h1 class="text-white">Open an account with Haggai</h1>
                        <p class="text-white">Understand what is the loan amount you are eligible for and what would the EMI be.you can apply as per your eligibility.</p>
                        <a href="#" class="btn btn-default">Open Account</a>
                    </div>
                    <!-- /.section title start-->
                </div>
            </div>
        </div>
    </div>
    
    
    
    <div class="section-space80 bg-white">
        <div class="container">
            <div class="row">
               <div class="offset-xl-2 col-xl-8 offset-md-2 col-md-8 offset-md-2 col-md-8 col-sm-12 col-12">
                    <div class="mb60 text-center section-title">
                        <!-- section title-->
                        <h1 style="color:#ce2b09">We are Here to Help You</h1>
                        <p>Our mission is to deliver reliable, latest news and opinions.</p>
                    </div>
                    <!-- /.section title-->
                </div>
            </div>
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="bg-white bg-boxshadow pinside40 outline text-center mb30">
                        <div class="mb40"><i class="fas fa-calendar-week fa-5x"></i></div>
                        <h2 class="capital-title">Apply For Loan</h2>
                        <p>Looking to buy a Home or Landed Property? then apply for loan now.</p>
                        <a href="#" class="btn-link">Get Appointment</a> </div>
                </div>
                 <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="bg-white bg-boxshadow pinside40 outline text-center mb30">
                        <div class="mb40">
                        <i class="fas fa-phone fa-5x"></i>
                            </div>
                        <h2 class="capital-title">Call us at </h2>
                        <h1 class="text-big">07045994840 </h1>
                        <p>lnfo@haggaibank.com</p>
                        <a href="#" class="btn-link">Contact us</a> </div>
                </div>
                <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                    <div class="bg-white bg-boxshadow pinside40 outline text-center mb30">
                        <div class="mb40"><i class="fas fa-calendar-week fa-5x"></i></div>
                        <h2 class="capital-title">Talk to Advisor</h2>
                        <p>Need to loan advise? Talk to our Loan advisors.</p>
                        <a href="#" class="btn-link">Meet The Advisor</a> </div>
                </div>
            </div>
        </div>
    </div>
     <div class="footer section-space100">
        <!-- footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-4 col-lg-4 col-md-4 col-sm-12 col-12">
                    <div class="footer-logo">
                        <!-- Footer Logo -->
                        <img src="images/ft-logo.png" alt="Borrow - Loan Company Website Templates"> </div>
                    <!-- /.Footer Logo -->
                </div>
                <div class="col-xl-8 col-lg-8 col-md-8 col-sm-12 col-12">
                    <div class="row">
                    <div class="col-xl-5 col-lg-5 col-md-5 col-sm-12 col-12">
                        <h3 class="newsletter-title">Signup Our Newsletter</h3>
                    </div>
                    <div class="col-xl-7 col-lg-7 col-md-7 col-sm-12 col-12">
                        <div class="newsletter-form">
                            <!-- Newsletter Form -->
                            <form action="newsletter.php" method="post">
                                <div class="input-group">
                                    <input type="email" class="form-control" id="newsletter" name="newsletter" placeholder="Write E-Mail Address" required>
                                    <span class="input-group-btn">
                <button class="btn btn-default" type="submit">Go!</button>
                </span> </div>
                                <!-- /input-group -->
                            </form>
                        </div>
                        <!-- /.Newsletter Form -->
                    </div>
                </div>
                    <!-- /.col-lg-6 -->
                </div>
            </div>
            <hr class="dark-line">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-12 col-12">
                    <div class="widget-text mt40">
                        <!-- widget text -->
                        <p>Our goal at Borrow Loan Company is to provide access to personal loans and education loan, car loan, home loan at insight competitive interest rates lorem ipsums. We are the loan provider, you can use our loan product.</p>
                        <div class="row">
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                <p class="address-text"><span><i class="icon-placeholder-3 icon-1x"></i> </span>3895 Sycamore Road Arlington, 97812 </p>
                            </div>
                            <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                                <p class="call-text"><span><i class="icon-phone-call icon-1x"></i></span>800-123-456</p>
                            </div>
                        </div>
                    </div>
                    <!-- /.widget text -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="#">Home</a></li>
                            <li><a href="#">Services</a></li>
                            <li><a href="#">About Us</a></li>
                            <li><a href="#">News</a></li>
                            <li><a href="#">Faq</a></li>
                            <li><a href="#">Contact Us</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="widget-footer mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="#">Car Loan</a></li>
                            <li><a href="#">Personal Loan</a></li>
                            <li><a href="#">Education Loan</a></li>
                            <li><a href="#">Business Loan</a></li>
                            <li><a href="#">Home Loan</a></li>
                            <li><a href="#">Debt Consolidation</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
                <div class="col-xl-2 col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="widget-social mt40">
                        <!-- widget footer -->
                        <ul class="listnone">
                            <li><a href="#"><i class="fa fa-facebook"></i>Facebook</a></li>
                            <li><a href="#"><i class="fa fa-google-plus"></i>Google Plus</a></li>
                            <li><a href="#"><i class="fa fa-twitter"></i>Twitter</a></li>
                            <li><a href="#"><i class="fa fa-linkedin"></i>Linked In</a></li>
                        </ul>
                    </div>
                    <!-- /.widget footer -->
                </div>
            </div>
        </div>
    </div>
    <!-- /.footer -->
    <div class="tiny-footer">
        <!-- tiny footer -->
        <div class="container">
            <div class="row">
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6">
                    <p>© Copyright 2016 | Borrow Loan Company</p>
                </div>
                <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6 text-right">
                    <p>Terms of use | Privacy Policy</p>

                </div>
            </div>
        </div>
    </div>
    <!-- back to top icon -->
    <a href="#0" class="cd-top" title="Go to top">Top</a>
    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="js/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/menumaker.js"></script>
  
    <!-- sticky header -->
    <script type="text/javascript" src="js/jquery.sticky.js"></script>
    <script type="text/javascript" src="js/sticky-header.js"></script>
    <!-- slider script -->
    <script type="text/javascript" src="js/owl.carousel.min.js"></script>
    <script type="text/javascript" src="js/slider-carousel.js"></script>
    <script type="text/javascript" src="js/service-carousel.js"></script>
    <!-- Back to top script -->
    <script src="js/back-to-top.js" type="text/javascript"></script>
</body>

</html>
